(function test(){
	
})()